import express from "express";
import dotenv from "dotenv";

import "./config/db.js";

import {
  getAllAnimals,
  getAnimalById,
  createAnimal,
  updateAnimal,
  deleteAnimal,
  getAnimalByName,
} from "./models/animalModel.js";

dotenv.config();

const app = express();

// Middleware
app.use(express.json());

// =======================
// TEST SERVER
// =======================

app.get("/", (req, res) => {
  res.json({
    message: "WildSense API Server is running",
  });
});

// =======================
// ANIMAL API
// =======================

// GET ALL ANIMALS
app.get("/api/animals", (req, res) => {
  getAllAnimals((error, result) => {
    if (error) {
      return res.status(500).json({
        message: error.message,
      });
    }
    res.json(result);
  });
});

// GET ANIMAL BY ID
app.get("/api/animals/:id", (req, res) => {
  const id = req.params.id;
  getAnimalById(id, (error, result) => {
    if (error) {
      return res.status(500).json({
        message: error.message,
      });
    }
    if (result.length === 0) {
      return res.status(404).json({
        message: "Animal not found",
      });
    }
    res.json(result[0]);
  });
});

// SEARCH ANIMAL BY NAME
app.get("/api/animals/search/:name", (req, res) => {
  const name = req.params.name;
  getAnimalByName(name, (error, result) => {
    if (error) {
      return res.status(500).json({
        message: error.message,
      });
    }
    res.json(result);
  });
});

// CREATE ANIMAL
app.post("/api/animals", (req, res) => {
  createAnimal(req.body, (error, result) => {
    if (error) {
      return res.status(400).json({
        message: error.message,
      });
    }
    res.status(201).json({
      message: "Animal created successfully",
      animal_id: result.insertId,
    });
  });
});

// UPDATE ANIMAL
app.put("/api/animals/:id", (req, res) => {
  const id = req.params.id;
  updateAnimal(id, req.body, (error, result) => {
    if (error) {
      return res.status(400).json({
        message: error.message,
      });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({
        message: "Animal not found",
      });
    }
    res.json({
      message: "Animal updated successfully",
    });
  });
});

// DELETE ANIMAL
app.delete("/api/animals/:id", (req, res) => {
  const id = req.params.id;
  deleteAnimal(id, (error, result) => {
    if (error) {
      return res.status(500).json({
        message: error.message,
      });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({
        message: "Animal not found",
      });
    }
    res.json({
      message: "Animal deleted successfully",
    });
  });
});

// =======================
// SERVER START
// =======================

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log("All routes loaded");
  console.log(`Server running on port ${PORT}`);
  console.log(`http://localhost:${PORT}`);
});
